//
//  ViewController.swift
//  TinyShieldDemo-UIKit
//
//  Created by Diana Ayala Galvan on 20/07/23.
//

import UIKit
import TinyShield

class ViewController: UIViewController {
    
    var tinyShieldView = TinyShieldView()
    var contentView = UIView()
    var titleLabel = UILabel()
    var imageView = UIImageView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpView()
    }
    
    func setUpView() {
        self.view.addSubview(tinyShieldView)
        setUpTinyShieldViewConstraints()
        contentView.backgroundColor = .brown
        tinyShieldView.addSubview(contentView)
        setUpContentViewConstraints()
        setUpTitleLabel()
        setUpImage()
    }
    
    func setUpTitleLabel() {
        titleLabel.text = "Some test title"
        titleLabel.numberOfLines = 0
        titleLabel.textAlignment = .center
        titleLabel.sizeToFit()
        titleLabel.font = titleLabel.font.withSize(30)
        contentView.addSubview(titleLabel)
        setUpTitleLabelConstraints()
    }
    
    func setUpImage() {
        imageView.image = UIImage(named: "IMG_8477")
        contentView.addSubview(imageView)
        setUpImageConstraints()
    }
    
    func setUpImageConstraints() {
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.constraint(.width, to: contentView, by: 0.6)
        imageView.constraint(.height, to: contentView, by: 0.4)
        imageView.constraint(.centerX, to: contentView)
        imageView.constraint(.centerY, to: contentView)
    }
    
    func setUpTitleLabelConstraints() {
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.constraint(.centerX, to: contentView)
        titleLabel.constraint(.centerY, to: contentView, by: 0.5)
    }
    
    func setUpTinyShieldViewConstraints() {
        tinyShieldView.translatesAutoresizingMaskIntoConstraints = false
        tinyShieldView.constraint(.width, to: self.view)
        tinyShieldView.constraint(.height, to: self.view)
        tinyShieldView.constraint(.centerX, to: self.view)
        tinyShieldView.constraint(.centerY, to: self.view)
    }
    
    func setUpContentViewConstraints() {
        contentView.translatesAutoresizingMaskIntoConstraints = false
        contentView.constraint(.width, to: tinyShieldView)
        contentView.constraint(.height, to: tinyShieldView)
        contentView.constraint(.centerX, to: tinyShieldView)
        contentView.constraint(.centerY, to: tinyShieldView)
    }
    
}

