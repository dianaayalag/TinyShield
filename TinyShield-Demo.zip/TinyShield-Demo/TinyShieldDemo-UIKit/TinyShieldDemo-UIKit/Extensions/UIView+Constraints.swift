//
//  Constraints.swift
//  TinyShieldDemo-UIKit
//
//  Created by Diana Ayala Galvan on 23/07/23.
//

import UIKit

extension UIView {
    
    func constraint(_ attribute: NSLayoutConstraint.Attribute, to secondItem: UIView) {
        self.constraint(attribute, to: secondItem, by: 1)
    }
    
    func constraint(_ attribute: NSLayoutConstraint.Attribute, to secondItem: UIView, by multiplier: Double) {
        NSLayoutConstraint(
            item: self,
            attribute: attribute,
            relatedBy: .equal,
            toItem: secondItem,
            attribute: attribute,
            multiplier: multiplier,
            constant: 0).isActive = true
    }
    
}
